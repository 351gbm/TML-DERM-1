import tensorflow as tf
import numpy as np
import pickle


CONFIG = dict(dim_hidden=[64, 64, 64], num_hidden_layers=3) 

def contruct_layer(inp, activation_fn, reuse, norm, is_train, scope):
    if norm == 'batch_norm':
        out = tf.contrib.layers.batch_norm(inp,
                                           activation_fn=activation_fn,
                                           reuse=reuse,
                                           is_training=is_train,
                                           scope=scope)
    elif norm == 'None':
        out = activation_fn(inp)
    else:
        ValueError('Can\'t recognize {}'.format(norm))

    return out


def construct_weights(dim_input, dim_output, ensembled_num, fold):
    weights_filename = './ML_weights/weights/weights-{}-fold'.format(fold)
    pre_w_file = open(weights_filename,'rb')
    pre_weights = pickle.load(pre_w_file)
    pre_w_file.close()
    
    weights = {}
    

    tmp = np.array(pre_weights['w1']).reshape(dim_input, CONFIG['dim_hidden'][0])
    weights['w1'] = tf.Variable(tmp)
    tmp = np.array(pre_weights['b1']).reshape(1, CONFIG['dim_hidden'][0])
    weights['b1'] = tf.Variable(tmp)
    for i in range(1, CONFIG['num_hidden_layers']):
        tmp = np.array(pre_weights['w'+str(i+1)]).reshape(CONFIG['dim_hidden'][i-1], CONFIG['dim_hidden'][i])
        weights['w'+str(i+1)] = tf.Variable(tmp)
        tmp = np.array(pre_weights['b'+str(i+1)]).reshape(1, CONFIG['dim_hidden'][i])
        weights['b'+str(i+1)] = tf.Variable(tmp)
        


    
    tmp = np.array(pre_weights['w'+str(CONFIG['num_hidden_layers']+1)]). \
        reshape(CONFIG['dim_hidden'][CONFIG['num_hidden_layers']-1], ensembled_num)
        
    weights['w'+str(CONFIG['num_hidden_layers']+1)] = tf.Variable(tmp)   # h x 5
    tmp = np.array(pre_weights['b'+str(CONFIG['num_hidden_layers']+1)]).reshape(1, ensembled_num)
    weights['b'+str(CONFIG['num_hidden_layers']+1)] = tf.Variable(tmp)
    
    constant_1 = np.array([1/ensembled_num]*ensembled_num).reshape(ensembled_num,1)
    weights['lambda'] = tf.Variable(constant_1, dtype=tf.float32) 

    return weights


def construct_forward(inp, weights, reuse, norm, is_train, prefix='erm'):
    h = contruct_layer(tf.matmul(inp, weights['w1']) + weights['b1'],
                       activation_fn=tf.nn.relu, reuse=reuse, is_train=is_train,
                       norm=norm, scope='1.'+prefix)
    for i in range(1, CONFIG['num_hidden_layers']):
        w = weights['w'+str(i+1)]
        b = weights['b'+str(i+1)]
        h = contruct_layer(tf.matmul(h, w)+b, activation_fn=tf.nn.relu,
                                 reuse=reuse, norm=norm, is_train=is_train,
                                 scope=str(i+1)+'.'+prefix)

    w = weights['w'+str(CONFIG['num_hidden_layers']+1)]
    b = weights['b'+str(CONFIG['num_hidden_layers']+1)]

    
    out_original = tf.matmul(h, w) + b # N x 5
    

    out = tf.matmul(out_original, weights['lambda']) 
    return out 


def get_session(num_cpu):
    tf_config = tf.ConfigProto(
        inter_op_parallelism_threads=num_cpu,
        intra_op_parallelism_threads=num_cpu)
    tf_config.gpu_options.per_process_gpu_memory_fraction = 1
    tf_config.gpu_options.allow_growth = True
    return tf.Session(config=tf_config)





