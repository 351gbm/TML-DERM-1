import argparse
import numpy as np

from maml import MAML

# usage:
# training  python main.py --is_train
# testing python main.py --restore_dir PATH_TO_CHECKPOINT

    #    self._task_name = 'MAML.{}_{}-shot_{}-updates_{}-batch_norm-{}'.\
    #       format(dataset.name, self._K,
    #             self._num_updates, self._batch_size,
    #             self._norm)
            
def argsparser():
    parser = argparse.ArgumentParser("Tensorflow Implementation of MAML")
    parser.add_argument('--seed', type=int, default=2)
    parser.add_argument('--ensembled_num', type=int, default=5) 
    # Dataset
    parser.add_argument('--dataset', help='environment ID', 
                        choices=['child_singleside','cs', 'breast_cancer', 'mci-nc', 'fMRI_MRI'],
                        default='child_singleside') 
    parser.add_argument('--fold', type=int, default = 2)
    # MAML
    parser.add_argument('--K', type=int, default=30) 
    parser.add_argument('--model_type', type=str, default='erm') # don't modify default 
    parser.add_argument('--loss_type', type=str, default='hinge_loss')
    parser.add_argument('--num_updates', type=int, default=10)
    parser.add_argument('--norm', choices=['None', 'batch_norm'], default='None')
    # Train
    parser.add_argument('--is_train', action='store_true', default=False)#
    parser.add_argument('--max_steps', type=int, default=201)
    parser.add_argument('--alpha', type=float, default=0.0075)
    parser.add_argument('--beta', type=float, default=0.0075)
    parser.add_argument('--batch_size', type=int, default=50)
    # Test
    parser.add_argument('--restore_checkpoint', type=str)
    parser.add_argument('--restore_dir', type=str)  
    parser.add_argument('--test_sample', type=int, default=2)
    args = parser.parse_args()
    return args


def get_dataset(dataset_name, K_shots, fold, ensembled_num):
    if dataset_name == 'breast_cancer' \
            or dataset_name == 'cs' \
            or dataset_name == 'mci-nc' \
            or dataset_name == 'fMRI_MRI'\
            or dataset_name == 'child_singleside':
        from dataset.dataload import dataset
    else:
        ValueError("Invalid dataset")
    return dataset(fold=fold, K_shots=K_shots, data_name=dataset_name, ensembled_num=ensembled_num)


def main(args):
    np.random.seed(args.seed)
    dataset = get_dataset(args.dataset, args.K, args.fold, args.ensembled_num)
    model = MAML(dataset, 
                 args.fold,
                 args.model_type,
                 args.loss_type,
                 dataset.dim_input,
                 dataset.dim_output,
                 args.alpha,
                 args.beta,
                 args.K,
                 args.batch_size,
                 args.is_train,
                 args.num_updates,
                 args.norm,
                 args.ensembled_num                 
                 )
    if args.is_train:
        print(args.dataset,' training') 
        model.learn(args.batch_size, dataset, args.max_steps, args.ensembled_num, dataset.num_test_sample)
    else:
        print(args.dataset,' testing')
        model.evaluate(dataset, args.test_sample, num_test_sample=dataset.num_test_sample,
                       restore_checkpoint=args.restore_checkpoint,
                       restore_dir=args.restore_dir)


if __name__ == '__main__':
    args = argsparser()
    main(args)
