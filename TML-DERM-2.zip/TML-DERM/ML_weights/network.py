import tensorflow as tf
import numpy as np


CONFIG = dict(dim_hidden=[64, 64, 64], num_hidden_layers=3) 

def contruct_layer(inp, activation_fn, reuse, norm, is_train, scope):
    if norm == 'batch_norm':
        out = tf.contrib.layers.batch_norm(inp,
                                           activation_fn=activation_fn,
                                           reuse=reuse,
                                           is_training=is_train,
                                           scope=scope)
    elif norm == 'None':
        out = activation_fn(inp)
    else:
        ValueError('Can\'t recognize {}'.format(norm))

    return out


def construct_weights(dim_input, dim_output, ensembled_num):
    weights = {}
    weights['w1'] = tf.Variable(tf.truncated_normal(
        [dim_input, CONFIG['dim_hidden'][0]], stddev=0.01))
    weights['b1'] = tf.Variable(tf.zeros([CONFIG['dim_hidden'][0]]))
    for i in range(1, CONFIG['num_hidden_layers']):
        weights['w'+str(i+1)] = tf.Variable(tf.truncated_normal(
            [CONFIG['dim_hidden'][i-1], CONFIG['dim_hidden'][i]], stddev=0.01))
        weights['b'+str(i+1)] = tf.Variable(tf.zeros([CONFIG['dim_hidden'][i]]))
    
    
    # initialization randomly
    weights['w'+str(CONFIG['num_hidden_layers']+1)] = \
        tf.Variable(tf.truncated_normal(
        [CONFIG['dim_hidden'][CONFIG['num_hidden_layers']-1], ensembled_num], stddev=0.01)
        )   # 34 x 5
    weights['b'+str(CONFIG['num_hidden_layers']+1)] = tf.Variable(tf.zeros([1,ensembled_num]))
    

    
    return weights


def construct_forward(inp, weights, reuse, norm, is_train, prefix='erm'):
    h = contruct_layer(tf.matmul(inp, weights['w1']) + weights['b1'],
                       activation_fn=tf.nn.relu, reuse=reuse, is_train=is_train,
                       norm=norm, scope='1.'+prefix)
    for i in range(1, CONFIG['num_hidden_layers']):
        w = weights['w'+str(i+1)]
        b = weights['b'+str(i+1)]
        h = contruct_layer(tf.matmul(h, w)+b, activation_fn=tf.nn.relu,
                                 reuse=reuse, norm=norm, is_train=is_train,
                                 scope=str(i+1)+'.'+prefix)

    w = weights['w'+str(CONFIG['num_hidden_layers']+1)]
    b = weights['b'+str(CONFIG['num_hidden_layers']+1)]
    out_original = tf.matmul(h, w) + b # Number_instances x 5
    
    
    out = out_original 

    return out 


def get_session(num_cpu):
    tf_config = tf.ConfigProto(
        inter_op_parallelism_threads=num_cpu,
        intra_op_parallelism_threads=num_cpu)
    tf_config.gpu_options.per_process_gpu_memory_fraction = 1
    tf_config.gpu_options.allow_growth = True
    return tf.Session(config=tf_config)





