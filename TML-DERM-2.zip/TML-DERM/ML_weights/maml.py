import os
from tqdm import tqdm
import tensorflow as tf
from loginfo import log
from utils import evaluation_criterion
import numpy as np
import pickle


# global variables for MAML
LOG_FREQ = 10#10
SUMMARY_FREQ = 10#10
SAVE_FREQ = 50#10
EVAL_FREQ = 20#50#10

num_hidden_layers = 3


class MAML(object):
    def __init__(self, dataset, fold, model_type, loss_type, dim_input, dim_output,
                 alpha, beta, K, batch_size, is_train, num_updates, norm, ensembled_num):
        '''
        model_tpye: choose model tpye for each task, choice: ('fc',)
        loss_type:  choose the form of the objective function
        dim_input:  input dimension
        dim_output: desired output dimension
        alpha:      fixed learning rate to calculate the gradient
        beta:       learning rate used for Adam Optimizer
        K:          perform K-shot learning
        batch_size: number of tasks sampled in each iteration
        '''
        self._loss_type = loss_type
        self._penalty_c = 1/2
        self._gamma = 0.5
        self._num_modality = 2
        self._is_train = is_train
        self._dataset = dataset
        self._fold = fold
        self._alpha = alpha
        self._K = K
        self._norm = norm
        self._ensembled_num = ensembled_num 
        self._dim_input = dim_input
        self._dim_output = dim_output
        self._batch_size = batch_size
        self._num_updates = num_updates
        self._meta_optimizer = tf.train.AdamOptimizer(beta)
        self._avoid_second_derivative = False
        self._task_name = 'MAML.{}_{}-fold_{}-shot_{}-updates_{}-batch_norm-{}'.\
            format(dataset.name, self._fold, self._K,
                   self._num_updates, self._batch_size,
                   self._norm)
            
        log.infov('Task name: {}'.format(self._task_name))

        # Build placeholder
        self._build_placeholder()


        model = self._import_model(model_type) 
        self._construct_weights = model.construct_weights
        self._contruct_forward = model.construct_forward
        self._sess = model.get_session(1)

        # build_graph
        self._build_graph(self._dim_input, self._dim_output, self._norm, self._ensembled_num) #gbm-20200220


        # Misc
        self._summary_dir = os.path.join('log', self._task_name)
        self._checkpoint_dir = os.path.join('checkpoint', self._task_name)
        self._saver = tf.train.Saver(max_to_keep=5)
        if self._is_train:
            if not os.path.exists(self._summary_dir):
                os.makedirs(self._summary_dir)
            self._writer = tf.summary.FileWriter(self._summary_dir, self._sess.graph)
            if not os.path.exists(self._checkpoint_dir):
                os.makedirs(self._checkpoint_dir)

        # Initialize all variables
        log.infov("Initialize all variables")
        self._sess.run(tf.global_variables_initializer())

    def _build_placeholder(self):
        self._meta_train_x = tf.placeholder(tf.float32)
        self._meta_train_y = tf.placeholder(tf.float32)
        self._meta_val_x = tf.placeholder(tf.float32)
        self._meta_val_y = tf.placeholder(tf.float32)

    def _import_model(self, model_type):
        if model_type == 'erm':
            import network as model
        else:
            ValueError("Can't recognize the model type {}".format(model_type))
        return model

    def _compute_loss(self, y, y_pre0, weights):

        if self._loss_type == 'hinge_loss':
            loss_hinge = self._penalty_c * tf.losses.hinge_loss(y, y_pre0) \
                         + tf.nn.l2_loss(weights['w'+str(num_hidden_layers+1)]) * 1 
                            
            
        else:
            ValueError("Can't recognize the loss type {}".format(self._loss_type))

        return loss_hinge

    def _computer_accuracy(self, output, y_label):

        output = tf.reduce_mean(output,axis=1)
        output = tf.identity(tf.sign(output), name='prediction')
        
        correct_prediction = tf.equal(output, tf.reduce_mean(y_label,axis=1)) 

        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
        return accuracy

    def _build_graph(self, dim_input, dim_output, norm, ensembled_num):

        self._weights = self._construct_weights(dim_input, dim_output, ensembled_num)

        # Calculate loss on 1 task
        ###### metastep_graph start###########
        def metastep_graph(inp): 
            meta_train_x, meta_train_y, meta_val_x, meta_val_y = inp

            meta_train_loss_list = []
            meta_val_loss_list = []

            meta_val_output_list = []

            weights = self._weights

            meta_train_output = self._contruct_forward(meta_train_x, weights,
                                                       reuse=False, norm=norm,
                                                       is_train=self._is_train) 

            meta_train_loss = self._compute_loss(y=meta_train_y, y_pre0=meta_train_output, weights=weights)

            meta_train_loss = tf.reduce_mean(meta_train_loss)
            meta_train_loss_list.append(meta_train_loss)


            grads = dict(zip(weights.keys(), tf.gradients(meta_train_loss, list(weights.values()))))


            new_weights = \
                dict(zip(weights.keys(), [weights[key] - self._alpha * grads[key] \
                                          for key in weights.keys()]))
 

            if self._avoid_second_derivative:
                new_weights = tf.stop_gradients(new_weights)


            # meta_val_output_original: N x 5
            meta_val_output = self._contruct_forward(meta_val_x, new_weights,
                                                     reuse=True, norm=norm,
                                                     is_train=self._is_train)
            meta_val_output_list.append(meta_val_output)
            # Meta val loss: Calculate loss (meta step)
            meta_val_loss = self._compute_loss(meta_val_y, meta_val_output, weights=new_weights)
            meta_val_loss = tf.reduce_mean(meta_val_loss)
            meta_val_loss_list.append(meta_val_loss)
            # If perform multiple updates
            for _ in range(self._num_updates - 1):
                meta_train_output = self._contruct_forward(meta_train_x, new_weights,
                                                           reuse=True, norm=norm,
                                                           is_train=self._is_train)

                meta_train_loss = self._compute_loss(meta_train_y, meta_train_output, weights=new_weights)
                meta_train_loss = tf.reduce_mean(meta_train_loss)
                meta_train_loss_list.append(meta_train_loss)

                grads = dict(
                    zip(new_weights.keys(), tf.gradients(meta_train_loss, 
                                                         list(new_weights.values()))))

                new_weights =                     \
                    dict(zip(new_weights.keys(), [new_weights[key] - self._alpha * grads[key]
                                                  for key in new_weights.keys()]))

                if self._avoid_second_derivative:
                    new_weights = tf.stop_gradients(new_weights)
                    
                meta_val_output = self._contruct_forward(meta_val_x, new_weights,
                                                         reuse=True, norm=norm,
                                                         is_train=self._is_train)
                meta_val_output_list.append(meta_val_output)

                meta_val_loss = self._compute_loss(meta_val_y, meta_val_output, weights=new_weights)
                meta_val_loss = tf.reduce_mean(meta_val_loss)
                meta_val_loss_list.append(meta_val_loss)

            # calculate ACC
         
            meta_train_accuracy = self._computer_accuracy(output=meta_train_output, 
                                                          y_label=meta_train_y)
            
            weights = new_weights  
            
            meta_val_accuracies = []
            for j in range(self._num_updates):
                meta_val_accuracies.append(
                    self._computer_accuracy(output=meta_val_output_list[j], y_label=meta_val_y))

            return [meta_train_loss_list, meta_val_loss_list,
                    meta_train_output, meta_val_output,
                    meta_train_accuracy, meta_val_accuracies,
                    weights]

        
            ###### metastep_graph end###########


        weights_out = {}
        for i_weights_out in range(1,num_hidden_layers+2):
            weights_out['w'+str(i_weights_out)] = tf.float32
            weights_out['b'+str(i_weights_out)] = tf.float32
            
                                
        output_dtype = [[tf.float32] * self._num_updates, [tf.float32] * self._num_updates,
                        tf.float32, tf.float32,
                        tf.float32, [tf.float32] * self._num_updates, weights_out]

        # tf.map_fn: map on the list of tensors unpacked from `elems` on dimension 0 (Task)
        # reture a packed value
        result = tf.map_fn(metastep_graph,
                           elems=(self._meta_train_x, self._meta_train_y,
                                  self._meta_val_x, self._meta_val_y),
                           dtype=output_dtype, parallel_iterations=self._batch_size)
        
        meta_train_losses, meta_val_losses, \
        meta_train_output, meta_val_output, \
        meta_train_accuracy, meta_val_accuracies, weights = result #

        self._weights1 = weights

        
        self._meta_val_output = meta_val_output
        self._meta_train_output = meta_train_output


        # Only look at the last final output
        meta_train_loss = tf.reduce_mean(meta_train_losses[-1])
        meta_val_loss = tf.reduce_mean(meta_val_losses[-1])

        # Loss
        self._meta_train_loss = meta_train_loss
        self._meta_val_loss = meta_val_loss

        # Accuracy
        meta_train_accuracy = tf.reduce_mean(meta_train_accuracy)
        meta_val_accuracy = tf.reduce_mean(meta_val_accuracies[-1])
        self._meta_train_accuracy = meta_train_accuracy
        self._meta_val_accuracy = meta_val_accuracy

        # Meta train step
        self._meta_train_op = self._meta_optimizer.minimize(meta_val_loss)

        # Summary
        self._meta_train_loss_sum = tf.summary.scalar('loss/meta_train_loss', meta_train_loss)
        self._meta_val_loss_sum = tf.summary.scalar('loss/meta_val_loss', meta_val_loss)
        self._meta_train_accuracy_sum = tf.summary.scalar('accuracy/meta_train_accuracy', 
                                                          meta_train_accuracy)
        self._meta_val_accuracy_sum = tf.summary.scalar('accuracy/meta_val_accuracy', 
                                                        meta_val_accuracy)
        self._summary_op = tf.summary.merge_all()

    # train model
    def learn(self, batch_size, dataset, max_steps, ensembled_num, num_test_sample):
        print('learning ...')
        for step in range(int(max_steps)):
            meta_val_accuracy, meta_train_accuracy, meta_val_loss, meta_train_loss, \
                meta_val_output, meta_train_output, summary_str, weights1 = \
                    self._single_train_step(dataset, batch_size, ensembled_num)
            

            if step % SUMMARY_FREQ == 0:
                self._writer.add_summary(summary_str, step)
            if step % LOG_FREQ == 0:
                log.info("Step: {}/{}, Meta train loss: {:.4f}, Meta val loss: {:.4f}, "
                         "Meta train acc: {:.4f}, Meta val acc: {:.4f}".format(
                    step, int(max_steps), meta_train_loss, meta_val_loss, meta_train_accuracy, 
                    meta_val_accuracy))
            if step % SAVE_FREQ == 0:
                log.infov("Save checkpoint-{}".format(step))
                self._saver.save(self._sess, os.path.join(self._checkpoint_dir, 'checkpoint'),
                                 global_step=step)
                                 
                                 
            if step % EVAL_FREQ == 0:
                self.evaluate(dataset, 1, num_test_sample, step=step)
                
                weights_filename = './weights/fold-{}/weights-{}-fold_{}-step'.\
                    format(self._fold, self._fold, step)
                
                weights = {}
                for i_weights in range(1,num_hidden_layers+2):
                    weights['w'+str(i_weights)] = weights1['w'+str(i_weights)][-1]
                    weights['b'+str(i_weights)] = weights1['b'+str(i_weights)][-1]
                    
                
                file_save = open(weights_filename,'wb')
                pickle.dump(weights, file_save)
                file_save.close()
            


    
    # test_steps: the number of test sample 
    def evaluate(self, dataset, test_steps, num_test_sample, **kwargs):
        if not self._is_train:
            assert kwargs['restore_checkpoint'] is not None or \
                   kwargs['restore_dir'] is not None
            if kwargs['restore_checkpoint'] is None:
                restore_checkpoint = tf.train.latest_checkpoint(kwargs['restore_dir'])
            else:
                restore_checkpoint = kwargs['restore_checkpoint']
            self._saver.restore(self._sess, restore_checkpoint)
            log.infov('Load model: {}'.format(restore_checkpoint))
            
        
        accumulated_val_loss = []
        accumulated_train_loss = []
        meta_val_accuracy_ = []
        for step in range(test_steps):
            print('test_steps', step)
            output, label, val_loss, train_loss, meta_val_accuracy, meta_train_accuracy, weights1 = \
                self._single_test_step(dataset, 1, self._fold, num_test_sample)
                

            label_ = np.squeeze(label[0])
            pre_out_ = np.squeeze(output[0])
            

            evaluation_criterion(label_, pre_out_) # for testing dataset, acc, sen, spe,...are calculated
            accumulated_val_loss.append(val_loss)
            accumulated_train_loss.append(train_loss)
            meta_val_accuracy_.append(meta_val_accuracy)

        val_loss_mean = sum(accumulated_val_loss) / test_steps
        train_loss_mean = sum(accumulated_train_loss) / test_steps
        
        # testing 
        if self._is_train:
            assert kwargs['step'] is not None
                
            acc_filename = './weights/fold-{}/acc-{}-fold_{}-step'.\
                    format(self._fold, self._fold, kwargs['step'])
            file_save = open(acc_filename,'wb')
            pickle.dump(meta_val_accuracy, file_save)
            file_save.close()
        

        log.infov("[Evaluate] Meta train loss: {:.8f}, Meta val loss: {:.8f}, Meta val acc: {:.8f}\n"
                  .format(train_loss_mean, val_loss_mean, meta_val_accuracy))

    def _single_train_step(self, dataset, batch_size, ensembled_num):
        batch_input, batch_target = dataset.get_batch(batch_size) # load training dataset

        feed_dict = {self._meta_train_x: batch_input[:, :self._K, :],
                     self._meta_train_y: batch_target[:, :self._K, :],
                     self._meta_val_x: batch_input[:, self._K:, :],
                     self._meta_val_y: batch_target[:, self._K:, :]}


        _, summary_str, meta_val_loss, meta_train_loss, meta_val_accuracy, meta_train_accuracy,\
            meta_val_output, meta_train_output, weights1 = \
            self._sess.run(\
            [self._meta_train_op, self._summary_op,
             self._meta_val_loss, self._meta_train_loss,
             self._meta_val_accuracy, self._meta_train_accuracy,
             self._meta_val_output, self._meta_train_output, self._weights1], feed_dict=feed_dict)
                

                

        return meta_val_accuracy, meta_train_accuracy, meta_val_loss, meta_train_loss, \
            meta_val_output, meta_train_output, summary_str, weights1 #meta_train_output_original, 

    def _single_test_step(self, dataset, batch_size, fold, num_test_sample):

        batch_input, batch_target = dataset.get_batch_t(batch_size) # load testing dataset, target 1x 104 x 5


        feed_dict = {self._meta_train_x: batch_input[:, :num_test_sample, :],
                     self._meta_train_y: batch_target[:, :num_test_sample, :],
                     self._meta_val_x: batch_input[:, num_test_sample:, :],
                     self._meta_val_y: batch_target[:, num_test_sample:, :]}

        meta_val_output, meta_val_loss, meta_train_loss, meta_val_accuracy, meta_train_accuracy, weights1 = \
            self._sess.run([self._meta_val_output, self._meta_val_loss,
                            self._meta_train_loss, self._meta_val_accuracy, self._meta_train_accuracy,
                            self._weights1],
                           feed_dict)
            

        return meta_val_output, batch_target[:, :num_test_sample, :], meta_val_loss, \
            meta_train_loss, meta_val_accuracy, meta_train_accuracy, weights1

