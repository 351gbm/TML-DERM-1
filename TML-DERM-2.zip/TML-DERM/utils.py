
from sklearn.metrics import confusion_matrix, roc_curve, auc
import numpy as np
import pickle

def evaluation_criterion(y_label, pre_out, **kwargs):
    #y_label, pre_out: N x 5


    # calculate the confusion matrix
    pre_out_ = [-1 if i < 0 else 1 for i in pre_out]
    tn, fp, fn, tp = confusion_matrix(y_label, pre_out_).ravel()

    if tp+fn+tn+fp==0:
        accuracy = 0.0
    else:
        accuracy = (tp + tn) / (tp + fn + tn + fp)
    
    if tp+fn==0:
        sensitivity = 0.0
    else:
        sensitivity = tp / (tp + fn)
    
    if tn+fp==0:
        specificity = 0.0
    else:
        specificity = tn / (tn + fp)
    
    YI = (sensitivity + specificity - 1)
    
    if tp+fp==0:
        PPV = 0.0
    else:
        PPV = tp / (tp + fp)
    
    if tn+fn==0:
        NPV = 0.0
    else:
        NPV = tn / (tn + fn)
    
    precision = PPV #tp / (tp + fp)
    recall = sensitivity #tp / (tp + fn)

    if precision==0 or recall==0:
        F1 = 0
    else:
        F1 = 2 / (1 / precision + 1 / recall)
    

    
    print('   accuracy:  {:.8f}'.format(accuracy * 100))
    print(' senitivity:  {:.8f}'.format(sensitivity * 100))
    print('specificity:  {:.8f}'.format(specificity * 100))
    print('         YI:  {:.8f}'.format(YI * 100))
    print('  precision:  {:.8f}'.format(precision * 100))
    print('     recall:  {:.8f}'.format(recall * 100))
    print('         F1:  {:.8f}'.format(F1 * 100))
    print('        PPV:  {:.8f}'.format(PPV * 100))
    print('        NPV:  {:.8f}'.format(NPV * 100))


    fpr, tpr, threshold = roc_curve(y_label, pre_out)
    roc_auc = auc(fpr, tpr)
    print('        AUC:  {:.8f}'.format(roc_auc))

    
    
    results_dict = dict(acc=accuracy,sen=sensitivity,spe=specificity,ppv=PPV,npv=NPV,label=y_label,pre_value=pre_out)
    if kwargs['fold'] is not None and kwargs['step_save'] is not -1:
        result_file = './results/fold-{}/child_{}-fold_{}-step'.\
                    format(kwargs['fold'], kwargs['fold'], kwargs['step_save'])
        file_save = open(result_file,'wb')
        pickle.dump(results_dict, file_save)
        file_save.close()            
        print('evaluation end.')


def sigmid(x):
    return 1 / (1 + np.exp(-x))
